package com.example.tasks.model;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "tarefas")
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @JsonProperty("title")
    private String titulo;

    @Column(length = 2000)
    @JsonProperty("detail")
    private String detalhamento;

    @NotBlank
    @JsonProperty("responsible")
    private String responsavel;

    @NotNull
    @JsonProperty("dueDate")
    private LocalDate dataTermino;

    public Task() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    @JsonProperty("title")
    public String getTitulo() { return titulo; }
    @JsonProperty("title")
    public void setTitulo(String titulo) { this.titulo = titulo; }

    @JsonProperty("detail")
    public String getDetalhamento() { return detalhamento; }
    @JsonProperty("detail")
    public void setDetalhamento(String detalhamento) { this.detalhamento = detalhamento; }

    @JsonProperty("responsible")
    public String getResponsavel() { return responsavel; }
    @JsonProperty("responsible")
    public void setResponsavel(String responsavel) { this.responsavel = responsavel; }

    @JsonProperty("dueDate")
    public LocalDate getDataTermino() { return dataTermino; }
    @JsonProperty("dueDate")
    public void setDataTermino(LocalDate dataTermino) { this.dataTermino = dataTermino; }
}
