package com.example.tasks.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.tasks.model.Task;
import com.example.tasks.repository.TaskRepository;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/tasks")
@CrossOrigin
public class TaskController {

    private final TaskRepository repositorio;

    public TaskController(TaskRepository repositorio) {
        this.repositorio = repositorio;
    }

    @GetMapping
    public List<Task> listar() {
        return repositorio.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Task> buscarPorId(@PathVariable Long id) {
        return repositorio.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> criar(@Valid @RequestBody Task tarefa) {
        Task tarefaSalva = repositorio.save(tarefa);
        return ResponseEntity.ok(tarefaSalva);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id, @Valid @RequestBody Task tarefa) {
        Optional<Task> encontrada = repositorio.findById(id);

        if (encontrada.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Task existente = encontrada.get();
        existente.setTitulo(tarefa.getTitulo());
        existente.setDetalhamento(tarefa.getDetalhamento());
        existente.setResponsavel(tarefa.getResponsavel());
        existente.setDataTermino(tarefa.getDataTermino());

        repositorio.save(existente);
        return ResponseEntity.ok(existente);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> excluir(@PathVariable Long id) {
        if (!repositorio.existsById(id)) {
            return ResponseEntity.notFound().build();
        }

        repositorio.deleteById(id);
        return ResponseEntity.ok().build();
    }
}
