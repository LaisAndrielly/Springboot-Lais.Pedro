const API = '/api/tasks';

async function fetchTasks(){
  const r = await fetch(API);
  renderList(await r.json());
}

function renderList(tasks){
  const list = document.getElementById('list');
  list.innerHTML = '';
  tasks.forEach(t=>{
    const atrasada = new Date(t.dueDate) < new Date(new Date().toDateString());
    const div = document.createElement('div');
    div.className = 'task';
    div.innerHTML = `
      <h3>${esc(t.title)}</h3>
      <div class="meta">Responsável: ${esc(t.responsible)}<br>Data de término: ${format(t.dueDate)}</div>
      ${atrasada ? '<div class="badge">ATRASADA</div>' : ''}
      <p>${esc(t.detail || '')}</p>
      <div class="actions">
        <button class="primary" onclick="edit(${t.id})">Alterar</button>
        <button class="danger" onclick="confirmDelete(${t.id})">Excluir</button>
      </div>
    `;
    list.appendChild(div);
  });
}

function format(d){
  return new Date(d).toLocaleDateString();
}

function esc(s){
  return s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
}

document.getElementById('newBtn').onclick = ()=>openModal();
document.getElementById('cancelBtn').onclick = closeModal;

document.getElementById('taskForm').onsubmit = async e=>{
  e.preventDefault();
  const id = taskId.value;
  const body = {
    title: title.value.trim(),
    detail: detail.value.trim(),
    responsible: responsible.value.trim(),
    dueDate: dueDate.value
  };
  if(!body.title || !body.responsible || !body.dueDate){
    formMsg.textContent = 'Campos obrigatórios faltando';
    return;
  }
  const opts = {method: id?'PUT':'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)};
  const r = await fetch(API + (id?'/'+id:''), opts);
  if(!r.ok){ formMsg.textContent = 'Erro ao salvar'; return; }
  closeModal();
  fetchTasks();
};

async function edit(id){
  const r = await fetch(API+'/'+id);
  if(!r.ok) return alert('Tarefa não encontrada');
  const t = await r.json();
  openModal(t);
}

function confirmDelete(id){
  if(confirm('Excluir tarefa '+id+'?')){
    fetch(API+'/'+id,{method:'DELETE'}).then(r=>{
      if(r.ok) fetchTasks();
    });
  }
}

function openModal(t){
  modal.classList.remove('hidden');
  formMsg.textContent='';
  if(t){
    modalTitle.textContent='Alterar tarefa - ID '+t.id;
    taskId.value=t.id;
    title.value=t.title;
    detail.value=t.detail;
    responsible.value=t.responsible;
    dueDate.value=t.dueDate;
  } else {
    modalTitle.textContent='Nova tarefa';
    taskId.value='';
    title.value='';
    detail.value='';
    responsible.value='';
    dueDate.value='';
  }
}

function closeModal(){
  modal.classList.add('hidden');
}

fetchTasks();
